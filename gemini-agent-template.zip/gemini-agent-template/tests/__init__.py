"""Zero-network tests for resilience.py and retry.py — no google.genai calls."""
