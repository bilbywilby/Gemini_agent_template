"""Smoke tests: package imports cleanly and exposes its declared public API."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from unittest.mock import patch

import pytest

import agent_framework


def test_package_exports() -> None:
    """Every name declared in __all__ must actually be importable from the package."""
    for name in agent_framework.__all__:
        assert hasattr(agent_framework, name), f"{name} declared in __all__ but not exported"


def test_version_is_valid_semver_like_string() -> None:
    assert isinstance(agent_framework.__version__, str)
    parts = agent_framework.__version__.split(".")
    assert len(parts) >= 2
    assert all(p.isdigit() for p in parts[:2])


@pytest.mark.parametrize(
    ("installed", "should_warn"),
    [
        ("1.39.0", True),   # below minimum
        ("1.9.0", True),    # below minimum — the exact case the old string compare missed
        ("1.40.0", False),  # exactly minimum
        ("1.41.0", False),  # above minimum
        ("2.0.0", False),   # above minimum, different major
    ],
)
def test_dependency_version_check_uses_semantic_comparison(
    installed: str, should_warn: bool
) -> None:
    """Regression test: version comparison must be numeric, not lexicographic."""
    with patch("importlib.metadata.version", return_value=installed):
        if should_warn:
            with pytest.warns(UserWarning):
                agent_framework._check_dependencies()
        else:
            with pytest.warns(None) as record:
                agent_framework._check_dependencies()
            assert len(record) == 0


def test_missing_package_metadata_does_not_raise() -> None:
    """If vertexai is importable but package metadata is missing, skip silently."""
    with patch("importlib.metadata.version", side_effect=PackageNotFoundError):
        agent_framework._check_dependencies()  # should not raise
