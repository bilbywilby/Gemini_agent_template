"""
agent_framework — Production-grade async agentic framework for Vertex AI (Gemini).

This framework provides a resilient ReAct-style agent loop with built-in:
- Circuit Breaking & Retries: protect your quota and handle transient failures.
- Parallel Tool Execution: run multiple tool calls simultaneously.
- Observability: in-process metrics for latency and error tracking.

Usage:
    >>> from agent_framework import AgentLoop, VertexClient, ToolRegistry, AgentConfig
    >>> client = VertexClient(project="my-project")
    >>> agent = AgentLoop(client=client, registry=ToolRegistry(), config=AgentConfig(system_prompt="..."))
    >>> turn = await agent.run("Calculate the current growth rate.")
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._version import __version__

# Core API Exports
from .agent import AgentConfig, AgentError, AgentLoop, Turn
from .circuit_breaker import AsyncCircuitBreaker, CircuitBreakerError, CircuitState
from .observability import AgentMetrics, LatencyRecord
from .retry import RetryPolicy
from .tools import ToolDefinition, ToolRegistry, ToolResult
from .vertex_client import VertexClient

# Heavy type imports are guarded for type checkers only
if TYPE_CHECKING:
    from vertexai.generative_models import Content, Tool  # noqa: F401

__all__ = [
    "__version__",
    "AgentConfig",
    "AgentError",
    "AgentLoop",
    "AgentMetrics",
    "AsyncCircuitBreaker",
    "CircuitBreakerError",
    "CircuitState",
    "LatencyRecord",
    "RetryPolicy",
    "ToolDefinition",
    "ToolRegistry",
    "ToolResult",
    "Turn",
    "VertexClient",
]

_MIN_AIPLATFORM_VERSION = "1.40.0"


def _check_dependencies() -> None:
    """Ensure the underlying Vertex AI SDK is installed with a compatible version.

    Raises:
        ImportError: if the ``google-cloud-aiplatform`` package is not installed.

    Warns:
        UserWarning: if the installed version predates the minimum tested
            against for stable async support.
    """
    try:
        import vertexai  # noqa: F401
    except ImportError as e:
        raise ImportError(
            "agent_framework requires the Vertex AI SDK. "
            f"Install it via: pip install google-cloud-aiplatform>={_MIN_AIPLATFORM_VERSION}"
        ) from e

    from importlib.metadata import PackageNotFoundError, version as pkg_version

    from packaging.version import InvalidVersion, Version

    try:
        installed = pkg_version("google-cloud-aiplatform")
    except PackageNotFoundError:
        # vertexai importable but package metadata missing (e.g. editable/vendored
        # install) — nothing reliable to compare against, so skip the check.
        return

    try:
        if Version(installed) < Version(_MIN_AIPLATFORM_VERSION):
            import warnings

            warnings.warn(
                f"google-cloud-aiplatform {installed} is older than the tested "
                f"minimum {_MIN_AIPLATFORM_VERSION} and may have unstable async support.",
                stacklevel=2,
            )
    except InvalidVersion:
        # Non-PEP440 version string (e.g. a vendor build tag) — don't block import.
        return


_check_dependencies()
